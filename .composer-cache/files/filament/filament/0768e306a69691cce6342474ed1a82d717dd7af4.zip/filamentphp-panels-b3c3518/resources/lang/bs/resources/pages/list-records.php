<?php

return [

    'breadcrumb' => 'Lista',

];
